<?php
include "Header.php"
  ?>

<!-- Page (2 columns) -->
<div id="page" class="box">
  <div id="page-in" class="box">
    <!-- Content -->
    <div id="content">
      <!-- Article -->
      <div class="article">
        <h2><span>Semester Management</span></h2>
       
        <p>
          <?php
          if (isset($_SESSION['message'])) {
            echo $_SESSION['message'];
            unset($_SESSION['message']);
          }
          ?>
        </p>
        
        <table width="100%" border="1" cellpadding="1" cellspacing="2" bordercolor="#006699">
          <tr>
            <th style="background-color:#006699; color:#fff;" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Program</strong></div>
            </th>
            <th style="background-color:#006699; color:#fff;" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Session</strong></div>
            </th>
            <th style="background-color:#006699; color:#fff;" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Start Date</strong></div>
            </th>
            <th style="background-color:#006699; color:#fff;" class="style3">
              <div align="left" class="style9 style5 style2"><strong>End Date</strong></div>
            </th>
            <th style="background-color:#006699; color:#fff;" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Batch Update</strong></div>
            </th>
            <th style="background-color:#006699; color:#fff;" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Batch Delete</strong></div>
            </th>
           
          </tr>
          <?php
          $selectQuery = "SELECT * FROM semester ORDER BY sem_id DESC";
          $result = $dbConnection->query($selectQuery);
          if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
              ?>
              <tr>
                
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <?php echo $row["s_program"] ?>
                  </div>
                </td>
               
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <?php echo $row["session"] ?>
                  </div>
                </td>
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <?php echo $row["s_start"] ?>
                  </div>
                </td>
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <?php echo $row["s_end"] ?>
                  </div>
                </td>
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <a href="./semesterUpdate.php?id=<?php echo $row['sem_id']; ?>">Update</a>
                  </div>
                </td>
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <a href="./php/semesterDelete.php?id=<?php echo $row['sem_id']; ?>">delete</a>
                  </div>
                </td>
              </tr>
              <?php
            }
          } ?>

        </table>

        <!-- adding add department button -->

        <div style="text-align:center;">
          <a href="./add_semester.php" class="button2" style="vertical-align:middle"><span>Add Semester</span></a>
        </div>


        <p class="btn-more box noprint">&nbsp;</p>
      </div> <!-- /article -->
      <hr class="noscreen" />

    </div> <!-- /content -->

    <?php
    include "right.php"
      ?>
  </div> <!-- /page-in -->
  <?php
  include "footer.php"
    ?>
</div> <!-- /page -->