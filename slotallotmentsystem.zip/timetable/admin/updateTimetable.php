<?php
require '../conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JSON data from the hidden input field
    $id = $_POST['id'];
    $jsonData = $_POST['jsonData'];
    echo $id;
    // Decode the JSON data into a PHP array
    $data = json_decode($jsonData, true);

    // Process and manipulate the data as needed
    // ...

    // Send a response if needed
    // For example, you can echo a success message
    $tableserialize = serialize($data);
    $table = $dbConnection->real_escape_string($tableserialize);
    $insertQuery = "UPDATE timetable SET timetable='$table' where id='$id'";
    if ($dbConnection->query($insertQuery) === true) {
        $_SESSION['message'] = "Update successfully";
        header("Location: ./generate.php");
        exit();
    } else {
        $_SESSION['message'] = "Error while updating";
        header("Location: ./generate.php");
        exit();
    }
}
