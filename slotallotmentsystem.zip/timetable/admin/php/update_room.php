<?php
require("../../conn.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    // Insert data into the course table
    $r_name = $_POST['r_name'];
    $r_capacity = $_POST['r_capacity'];
    $r_lab = $_POST['r_lab'];


    $sql = "UPDATE room SET r_name='$r_name', r_capacity='$r_capacity',r_lab='$r_lab' WHERE r_id = $id";

    if ($dbConnection->query($sql) === TRUE) {
        $_SESSION['message'] = "Data update successfully";
        header("Location: ../room_detail.php");
        exit();
    } else {
        $_SESSION['message'] = "Error inserting data";
        header("Location: ../room_detail.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../room_detail.php");
}
// Close the database connection
$dbConnection->close();
?>