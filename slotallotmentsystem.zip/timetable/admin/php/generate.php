<?php
require '../../conn.php';
$roomQuery = "SELECT * FROM room";
$roomResult = $dbConnection->query($roomQuery);
$rooms = array();
if ($roomResult->num_rows > 0) {
    // Loop through the result and store room data in the array
    while ($row = $roomResult->fetch_assoc()) {
        $rooms[] = $row;
    }
} else {
    echo "No rooms found.";
}

// SQL query to get data of courses with enrolled students
$courseQuery = "SELECT
    courses.c_id AS CourseID,
    courses.c_title AS CourseTitle,
    courses.c_credit AS credit,
    courses.c_lab AS lab,
    courses.c_semester AS semester,
    COUNT(students.s_id) AS EnrolledStudentCount
FROM
    courses
LEFT JOIN
    registration ON courses.c_id = registration.course_id
LEFT JOIN
    students ON registration.student_id = students.s_id
GROUP BY
    courses.c_id, courses.c_title;";

// Execute the query
$courseQueryResult = $dbConnection->query($courseQuery);
$courses = array();
// Check if there are rows in the result
if ($courseQueryResult->num_rows > 0) {
    // Loop through the result and display the course information with enrolled students
    while ($course = $courseQueryResult->fetch_assoc()) {
        $courses[$course['CourseTitle']] = $course;
    }
} else {
    echo "No courses found with enrolled students.";
}

// echo "<pre>course";
// print_r($courses);
// echo "</pre>";

$sql = "SELECT
    t.t_name AS TeacherName,
    tc.teacher_id AS TeacherID,
    CONCAT('[', GROUP_CONCAT(CONCAT('{\"course\":\"', c.c_title, '\",\"session\":\"', tc.session, '\"}') SEPARATOR ','), ']') AS subject
FROM
    teachers AS t
JOIN
    teachers_courses AS tc ON t.t_id = tc.teacher_id
JOIN
    courses AS c ON tc.course_id = c.c_id
GROUP BY
    t.t_id, t.t_name";

// Execute the query
$result = $dbConnection->query($sql);

// Check if there are rows in the result
$teachersArray = array();
if ($result->num_rows > 0) {
    // Initialize an empty teachers array

    // Loop through the result and store teacher data in the array
    while ($row = $result->fetch_assoc()) {
        $subject = array();
        $coursesArray = json_decode($row['subject'], true);

        // Initialize an empty subject array for each teacher

        // Loop through the courses and add them to the subject array

        $teacherData = array(
            "TeacherID" => $row["TeacherID"],
            "TeacherName" => $row["TeacherName"],
            "subject" => $coursesArray,
        );

        // Add the teacher data to the teachers array
        $teachersArray[$teacherData['TeacherID']] = $teacherData;
    }
} else {
    echo "No teachers found with courses.";
}

// echo "<pre>teacher";
// print_r($teachersArray);
// echo "</pre>";

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
$sessions = ['morning', 'evening'];
$timeSlots = [
    '9:00 AM - 10:30 AM',
    '11:00 AM - 12:30 PM',
    '12:35 AM - 2:05 PM',
    '2:10 PM - 3:40 PM',
    '4:00 PM - 5:30 PM',
];

// Initialize an array to store student data
$studentsArray = array();

// SQL query to get all students with their enrolled courses
$studentQuery = "SELECT
            students.s_id AS StudentID,
            students.s_name AS StudentName,
            students.s_session AS session,
            GROUP_CONCAT(courses.c_title) AS EnrolledCourses
        FROM
            students
        LEFT JOIN
            registration ON students.s_id = registration.student_id
        LEFT JOIN
            courses ON registration.course_id = courses.c_id
        GROUP BY
            students.s_id, students.s_name";

// Execute the query
$resultStudentQuery = $dbConnection->query($studentQuery);

// Check if there are rows in the result
if ($resultStudentQuery->num_rows > 0) {
    // Loop through the resultStudentQuery and store student data in the array
    while ($studenstData = $resultStudentQuery->fetch_assoc()) {
        // Split the EnrolledCourses string into an array of subjects
        $enrolledCoursesArray = explode(',', $studenstData["EnrolledCourses"]);

        // Add student data to the array with subjects as arrays
        $studentData = array(
            "StudentID" => $studenstData["StudentID"],
            "StudentName" => $studenstData["StudentName"],
            "session" => $studenstData["session"] ? "morning" : "evening",
            "EnrolledCourses" => $enrolledCoursesArray,
        );

        // Add the student data to the students array
        $studentsArray[] = $studentData;
    }
} else {
    // echo "No students found with enrolled courses.";
}
echo "<pre>student";
print_r($studentsArray);
echo "</pre>";

// Initialize an empty timetable
function generateTimetable($days, $sessions, $timeSlots, $teacherArray, $subjectArray, $roomArray, $studentsArray)
{
    $timetable = [];
    $assignedSubjects = [];

    foreach ($days as $day) {
        $assignedSubjects[$day] = [];

        foreach ($timeSlots as $timeSlot) {
            $assignedTeachers = [];
            $assignedRooms = [];
            $studentSubjects = [];
            // check for students

            foreach ($sessions as $session) {
                foreach ($teacherArray as $teacher) {
                    $subjects = $teacher['subject'];

                    foreach ($subjects as $subject) {
                        if ($subject['session'] === $session && isset($subjectArray[$subject['course']])) {
                            $subjectKey = $subject['course'] . ' - ' . $teacher['TeacherName'] . ' - ' . $subject['session'];
                            $teacherKey = $timeSlot . ' - ' . $teacher['TeacherName'];

                            $subjectKeyToCount = array_count_values(array_merge(...array_values($assignedSubjects)));
                            if (!isset($subjectKeyToCount[$subjectKey])) {
                                $subjectKeyToCount[$subjectKey] = 0;
                            }

                            if (!in_array($subjectKey, $assignedSubjects[$day]) && $subjectKeyToCount[$subjectKey] < $subjectArray[$subject['course']]['credit']) {
                                if (!isset($assignedTeachers[$teacherKey])) { // Check if teacher is already assigned
                                    $studentAlready = false;
                                    foreach ($studentsArray as $students) {
                                        foreach ($students['EnrolledCourses'] as $sbj) {
                                            $key = $students['session'] . '-' . $sbj;
                                            if (in_array($key, $studentSubjects)) {
                                                // echo "already<br>" . $day . $timeSlot;
                                                $studentAlready = true;
                                                break;
                                            }
                                        }
                                    }

                                    foreach ($roomArray as $room) {
                                        // create a check to students
                                        if ($room['r_capacity'] >= $subjectArray[$subject['course']]['EnrolledStudentCount'] &&
                                            $room['r_lab'] === $subjectArray[$subject['course']]['lab'] &&
                                            !in_array($room['r_name'], $assignedRooms) && !$studentAlready
                                        ) {

                                            $timetable[$day][$session][$timeSlot][] = [
                                                'room' => $room['r_name'],
                                                'teacher' => $teacher['TeacherName'],
                                                'subject' => $subjectArray[$subject['course']]['CourseID'],
                                            ];

                                            $assignedSubjects[$day][] = $subjectKey;
                                            $assignedTeachers[$teacherKey] = true; // Mark teacher as assigned
                                            $assignedRooms[] = $room['r_name'];
                                            $studentSubjects[] = $session . '-' . $subjectArray[$subject['course']]['CourseTitle'];
                                            break; // Assign the subject once and break from the room loop
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                // echo "<pre>";
                // print_r($studentSubjects);
                // echo "</pre>";

            }
        }
    }

    return $timetable;

}

// Example usage:
$timetable = generateTimetable($days, $sessions, $timeSlots, $teachersArray, $courses, $rooms, $studentsArray);
$tableserialize = serialize($timetable);
$table = $dbConnection->real_escape_string($tableserialize);
$insertQuery = "INSERT INTO timetable (timetable, status) VALUES ('$tableserialize', 'available')";
if ($dbConnection->query($insertQuery) === true) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../generate.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting values";
    header("Location: ../generate.php");
    exit();
}
