<?php
require('../../conn.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $session = $_POST['session'];
    $program = $_POST['program'];
    $s_start = $_POST['s_start'];
    $s_end = $_POST['s_end'];
    
    // Check if days exist and add them to the $availability array
    $selectQuery = "SELECT * FROM semester WHERE sem_id = $id";
    $result = $dbConnection->query($selectQuery);
    if ($result->num_rows > 0) {
        $sql = "UPDATE semester SET session='$session', s_program='$program',s_start='$s_start',s_end='$s_end' WHERE sem_id = $id";
        if ($dbConnection->query($sql) === TRUE) {
            $_SESSION['message'] = "Data Update successfully";
            header("Location: ../semesterView.php");
            exit();
        } else {
            $_SESSION['message'] = "Error Update values";
            header("Location: ../semesterView.php");
        }
    } else {
        $_SESSION['message'] = "Does not exits";
        header("Location: ../semesterView.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../semesterView.php");
}

// Close the database connection
$conn->close();
?>