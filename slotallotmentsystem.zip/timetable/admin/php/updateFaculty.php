<?php
require('../../conn.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $t_name = $_POST['t_name'];
    $t_email = $_POST['t_email'];
    
    // Check if days exist and add them to the $availability array
    $selectQuery = "SELECT * FROM teachers WHERE t_id = $id";
    $result = $dbConnection->query($selectQuery);
    if ($result->num_rows > 0) {
        $sql = "UPDATE teachers SET t_name='$t_name', t_email='$t_email' WHERE t_id = $id";
        if ($dbConnection->query($sql) === TRUE) {
            $_SESSION['message'] = "Data Update successfully";
            header("Location: ../faculty_details.php");
            exit();
        } else {
            $_SESSION['message'] = "Error Update values";
            header("Location: ../faculty_details.php");
        }
    } else {
        $_SESSION['message'] = "Does not exits";
        header("Location: ../faculty_details.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../faculty_details.php");
}

// Close the database connection
$conn->close();
?>