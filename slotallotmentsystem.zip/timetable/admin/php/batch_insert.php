<?php
require("../../conn.php");

// Insert data into the course table
$b_year = $_POST['b_year'];
$b_start = $_POST['b_start'];
$b_end = $_POST['b_end'];

$insertQuery = "INSERT INTO batch (b_year,b_startDate,b_endDate)
               VALUES ('$b_year','$b_start','$b_end')";

if ($dbConnection->query($insertQuery) === TRUE) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../batch_detail.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting data";
    header("Location: ../batch_detail.php");
}

// Close the database connection
$dbConnection->close();
?>