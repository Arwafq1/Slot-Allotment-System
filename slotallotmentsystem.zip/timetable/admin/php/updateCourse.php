<?php
require("../../conn.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    // Insert data into the course table
    $c_id = $_POST['c_id'];
    $c_title = $_POST['c_title'];
    $c_credit = $_POST['c_credit'];
    $c_semester = $_POST['c_semester'];
    $c_lab = $_POST['c_lab'];


    $sql = "UPDATE courses SET 	c_id='$c_id', c_title='$c_title', c_credit='$c_credit',c_semester='$c_semester', c_lab='$c_lab' WHERE c_id = '$id'";

    if ($dbConnection->query($sql) === TRUE) {
        $_SESSION['message'] = "Data update successfully";
        header("Location: ../course_details.php");
        exit();
    } else {
        $_SESSION['message'] = "Error inserting data";
        header("Location: ../course_details.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../course_details.php");
}
// Close the database connection
$dbConnection->close();
?>