<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the POST request

    $response = ['success' => true, 'message' => 'Timetable entry updated successfully'];

    echo json_encode($response);
} else {
    header("HTTP/1.0 405 Method Not Allowed");
    echo "Method Not Allowed";
}
