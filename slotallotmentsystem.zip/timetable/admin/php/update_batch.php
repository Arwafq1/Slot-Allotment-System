<?php
require("../../conn.php");
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $b_year = $_POST['b_year'];
    $b_startDate = $_POST['b_startDate'];
    $b_endDate = $_POST['b_endDate'];
    $sql = "UPDATE batch SET b_year='$b_year', b_startDate='$b_startDate',b_endDate='$b_endDate' WHERE b_id = $id";

    if ($dbConnection->query($sql) === TRUE) {
        $_SESSION['message'] = "Data update successfully";
        header("Location: ../batch_detail.php");
        exit();
    } else {
        $_SESSION['message'] = "Error inserting data";
        header("Location: ../batch_detail.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../batch_detail.php");
}
// Close the database connection
$dbConnection->close();
?>