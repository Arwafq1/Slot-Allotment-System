<?php
require('../../conn.php');
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $teacher_id = $_POST['teacher'];
    $course_id = $_POST['course_id'];
    $session = $_POST['session'];
    // Check if days exist and add them to the $availability array
    $selectQuery = "SELECT * FROM teachers_courses WHERE tc_id = $id";
    $result = $dbConnection->query($selectQuery);
    if ($result->num_rows > 0) {
        $sql = "UPDATE teachers_courses SET teacher_id='$teacher_id', course_id='$course_id',session='$session' WHERE tc_id = $id";
        if ($dbConnection->query($sql) === TRUE) {
            $_SESSION['message'] = "Data Update successfully";
            header("Location: ../faculty_courses.php");
            exit();
        } else {
            $_SESSION['message'] = "Error Update values";
            header("Location: ../faculty_courses.php");
        }
    } else {
        $_SESSION['message'] = "Does not exits";
        header("Location: ../faculty_courses.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../faculty_courses.php");
}

// Close the database connection
$conn->close();
?>