<?php
require("../../conn.php");

// Insert data into the course table
$session = $_POST['session'];
$program = $_POST['program'];
$s_start = $_POST['s_start'];
$s_end = $_POST['s_end'];

$insertQuery = "INSERT INTO semester (s_program,session,s_start,s_end)
               VALUES ('$program','$session','$s_start','$s_end')";

if ($dbConnection->query($insertQuery) === TRUE) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../semesterView.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting data";
    header("Location: ../semesterView.php");
}

// Close the database connection
$dbConnection->close();
?>