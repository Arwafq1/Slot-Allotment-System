<?php
require('../../conn.php');
$student_name = $_POST['student_name'];
$c_id = $_POST['c_id'];


$insertQuery = "INSERT INTO registration (student_id,course_id) VALUES ('$student_name','$c_id')";
if ($dbConnection->query($insertQuery) === TRUE) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../student_course.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting values";
    header("Location: ../student_course.php");
}

// Close the database connection
$conn->close();
?>