<?php 

require('../../conn.php');

// Get data from the form
$c_title = $_POST['title'];
$c_semester = $_POST['semester'];
$c_id = $_POST['id'];
$c_lab = $_POST['lab'];
$c_credit = $_POST['credit'];

// Check if any of the required values are missing
if (empty($c_title) || empty($c_semester) || empty($c_id) || !isset($c_lab) || !isset($c_credit)) {
    // Missing required values, show an error message
    $_SESSION['message'] = "Please provide all required values.";
    header("Location: ../course_details.php");
    exit();
}

// Check if c_id or c_title already exists
$checkQuery = "SELECT COUNT(*) AS count FROM courses WHERE c_id = '$c_id' OR c_title = '$c_title'";
$result = $dbConnection->query($checkQuery);
$row = $result->fetch_assoc();
if ($row['count'] > 0) {
    // c_id or c_title already exists, handle the error or show a message
    $_SESSION['message'] = "Course with ID $c_id or title '$c_title' already exists.";
    header("Location: ../course_details.php");
    exit();
}

// If all values are provided and c_id and c_title don't exist, proceed with the INSERT query
$insertQuery = "INSERT INTO courses (c_id, c_title, c_semester, c_lab, c_credit)
               VALUES ('$c_id', '$c_title', '$c_semester', '$c_lab', $c_credit)";

if ($dbConnection->query($insertQuery) === TRUE) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../course_details.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting data";
    header("Location: ../course_details.php");
}

// Close the database connection
$dbConnection->close();

?>