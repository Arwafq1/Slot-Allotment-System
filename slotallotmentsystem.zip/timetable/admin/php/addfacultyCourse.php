<?php 

require('../../conn.php');

// Get data from the form
$teacher_id = $_POST['teacher_id'];
$course_id = $_POST['course_id'];
$session = $_POST['session'];
// Check if the teacher with the same email already exists
$checkQuery = "SELECT COUNT(*) AS count FROM teachers_courses WHERE teacher_id = '$teacher_id' and course_id = '$course_id' and session = '$session'";
$result = $dbConnection->query($checkQuery);
$row = $result->fetch_assoc();
if ($row['count'] > 0) {
    // Teacher with the same email already exists, show an error message
    $_SESSION['message'] = "Teacher with course id '$course_id' already exits";
    header("Location: ../faculty_courses.php");
    exit();
}

// If the teacher with the same email doesn't exist, proceed with the INSERT query
$insertQuery = "INSERT INTO teachers_courses (teacher_id, course_id,session) VALUES ('$teacher_id', '$course_id','$session')";

if ($dbConnection->query($insertQuery) === TRUE) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../faculty_courses.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting data";
    header("Location: ../faculty_courses.php");
}

// Close the database connection
$dbConnection->close();

?>