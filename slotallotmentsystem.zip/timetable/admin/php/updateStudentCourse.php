<?php
require('../../conn.php');
if (isset($_GET['s_id'])) {
    $id = $_GET['s_id'];

    $student_id = $_POST['student_name'];
    $course_id = $_POST['c_id'];
    
    $selectQuery = "SELECT * FROM registration WHERE sc_id = '$id'";
    $result = $dbConnection->query($selectQuery);
    if ($result->num_rows > 0) {
        $sql = "UPDATE registration SET student_id='$student_id', course_id='$course_id' WHERE sc_id = '$id'";
        if ($dbConnection->query($sql) === TRUE) {
            $_SESSION['message'] = "Data Update successfully";
            header("Location: ../student_course.php");
            exit();
        } else {
            $_SESSION['message'] = "Error Update values";
            header("Location: ../student_course.php");
        }
    } else {
        $_SESSION['message'] = "Does not exits";
        header("Location: ../student_course.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../student_course.php");
}

// Close the database connection
$conn->close();
?>