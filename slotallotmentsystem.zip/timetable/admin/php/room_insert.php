<?php
require("../../conn.php");

// Insert data into the course table
$r_name = $_POST['r_name'];
$r_capacity = $_POST['r_capacity'];
$r_lab = $_POST['r_lab'];

$insertQuery = "INSERT INTO room (r_name, r_capacity,r_lab)
               VALUES ('$r_name', $r_capacity,'$r_lab')";

if ($dbConnection->query($insertQuery) === TRUE) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../room_detail.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting data";
    header("Location: ../room_detail.php");
}

// Close the database connection
$dbConnection->close();
?>