<?php 

require('../../conn.php');

// Get data from the form
$t_name = $_POST['t_name'];
$t_email = $_POST['t_email'];

// Check if the teacher with the same email already exists
$checkQuery = "SELECT COUNT(*) AS count FROM teachers WHERE t_email = '$t_email' or t_name = '$t_name'";
$result = $dbConnection->query($checkQuery);
$row = $result->fetch_assoc();
if ($row['count'] > 0) {
    // Teacher with the same email already exists, show an error message
    $_SESSION['message'] = "Teacher with email '$t_email' or name '$t_name' already exists.";
    header("Location: ../faculty_details.php");
    exit();
}

// If the teacher with the same email doesn't exist, proceed with the INSERT query
$insertQuery = "INSERT INTO teachers (t_name, t_email) VALUES ('$t_name', '$t_email')";

if ($dbConnection->query($insertQuery) === TRUE) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../faculty_details.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting data";
    header("Location: ../faculty_details.php");
}

// Close the database connection
$dbConnection->close();

?>