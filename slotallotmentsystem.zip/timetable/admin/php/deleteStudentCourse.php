<?php
require('../../conn.php');
if (isset($_GET['s_id'])) {
    $s_id = $_GET['s_id'];
    $sql = "DELETE FROM registration WHERE sc_id = '$s_id'";
    if ($dbConnection->query($sql) === TRUE) {
        $_SESSION['message'] = "Record deleted successfully.";
        header("Location: ../student_course.php");
        exit();
    } else {
        $_SESSION['message'] = "Error deleting record.";
        header("Location: ../student_course.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../student_course.php");
}

// Close the connection
$dbConnection->close();
$conn->close();
?>