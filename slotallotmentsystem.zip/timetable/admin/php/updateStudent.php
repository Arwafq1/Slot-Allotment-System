<?php
require('../../conn.php');
if (isset($_GET['s_id'])) {
    $id = $_GET['s_id'];

    $s_id = $_POST['s_id'];
    $s_name = $_POST['s_name'];
    $s_session = $_POST['s_session'];
    $s_batch = $_POST['batch'];
    
    $selectQuery = "SELECT * FROM students WHERE s_id = '$id'";
    $result = $dbConnection->query($selectQuery);
    if ($result->num_rows > 0) {
        $sql = "UPDATE students SET s_id='$s_id', s_name='$s_name', s_session=$s_session, s_batch='$s_batch' WHERE s_id = '$id'";
        if ($dbConnection->query($sql) === TRUE) {
            $_SESSION['message'] = "Data Update successfully";
            header("Location: ../student_details.php");
            exit();
        } else {
            $_SESSION['message'] = "Error Update values";
            header("Location: ../student_details.php");
        }
    } else {
        $_SESSION['message'] = "Does not exits";
        header("Location: ../student_details.php");
    }
} else {
    $_SESSION['message'] = "No ID specified.";
    header("Location: ../student_details.php");
}

// Close the database connection
$conn->close();
?>