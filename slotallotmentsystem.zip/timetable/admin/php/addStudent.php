<?php
require('../../conn.php');
$s_id = $_POST['s_id'];
$s_name = $_POST['s_name'];
$s_batch = $_POST['s_batch'];
$s_session = $_POST['s_session'];
$insertQuery = "INSERT INTO students (s_id,s_name,s_batch, s_session) VALUES ('$s_id','$s_name', '$s_batch','$s_session')";
if ($dbConnection->query($insertQuery) === TRUE) {
    $_SESSION['message'] = "Data inserted successfully";
    header("Location: ../student_details.php");
    exit();
} else {
    $_SESSION['message'] = "Error inserting values";
    header("Location: ../student_details.php");
}

// Close the database connection
$conn->close();
?>