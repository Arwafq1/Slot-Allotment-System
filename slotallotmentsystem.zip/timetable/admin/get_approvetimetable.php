<?php
include "../conn.php";
$timetable = [];
$sql = "SELECT * FROM timetable WHERE status = 'approve'";
$result = $dbConnection->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $time = $row['timetable'];
            $table = unserialize($time);
            $timetable = $table;
        }
    }
}

// Return the timetable data as JSON
header('Content-Type: application/json');
echo json_encode($timetable);
