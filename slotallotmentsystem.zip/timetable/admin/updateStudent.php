<?php include "Header.php" ?>
<div id="page" class="box">
    <div id="page-in" class="box">

        <div id="content">

            <div class="article">
                <h2><span>Student Details</span></h2>
                <div class="login">
                    <?php
                    $s_id = $_GET['s_id'];
                    $selectQuery = "SELECT * FROM students WHERE s_id = '$s_id'";
                    $result = $dbConnection->query($selectQuery);
                    if ($result->num_rows > 0) {
                        // Fetch the data from the result set
                        $row = $result->fetch_assoc();
                        ?>
                        <form action="./php/updateStudent.php?s_id=<?php echo $s_id ?>" method="post"
                            enctype="multipart/form-data" id="form2">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td>Student id:</td>
                                    <td> <input type="text" value="<?php echo $row['s_id'] ?>" name="s_id" id="txtName" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>Student Name:</td>
                                    <td><input type="text" value="<?php echo $row['s_name'] ?>" name="s_name"
                                            id="txtEmail" /></td>
                                </tr>
                                <tr>
                                    <td>Sessions:</td>
                                    <td>
                                    <select style="width:100%" name="s_session">
									    <option selected disabled>select session</option>
                                        
										<option value='1' <?php echo ($row["s_session"] == 1) ? 'selected' : ''; ?>>Morning</option>
										<option value='0' <?php echo ($row["s_session"] == 0) ? 'selected' : ''; ?>>Evening</option>
									</select>

                                    </td>
                                    
                                </tr>
                                  
                                <tr>
                                    <td>Batch:</td>
                                    <td>
                                        
                                    <select  style="width:100%" name="batch" >
                                        <option disabled>select batch</option>
                                            <?php
                                            $batchQuery = "SELECT * FROM batch ORDER BY b_id DESC";
                                            $batchResult = $dbConnection->query($batchQuery);
                                            if ($batchResult->num_rows > 0) {
                                                while ($batch = $batchResult->fetch_assoc()) {
                                                    $selected = ($batch["b_id"] == $row['s_batch']) ? 'selected' : '';
                                                    ?>
                                                    <option <?php echo $selected ?> value='<?php echo $batch["b_id"]?>' ><?php echo $batch['b_year'] ?></option>
                                                    <?php
                                                }
                                            } ?>
                                        </select>

                                    </td>
                                    
                                </tr>
                                <tr>
                                    <td colspan="2"><label> <label></label>
                                            <div align="center"> <input type="submit" name="button2" id="button2"
                                                    value="Update" /> </div>
                                        </label></td>
                                </tr>
                            </table>
                        </form>
                    <?php } ?>
                </div>
                <p class="btn-more box noprint">&nbsp;</p>
            </div> <!-- /article -->

        </div> <!-- /content -->
        <?php include "right.php" ?>
    </div> <!-- /page-in -->
    <?php include "footer.php" ?>