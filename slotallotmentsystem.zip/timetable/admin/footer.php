<div id="footer">
  
    <hr class="noscreen" />
    <p class="style1" id="createdby"> </p>
    <p id="copyright">Batch 2023 </p>
</div>
</div>
<script src="./js/multiselect-dropdown.js"></script>
</body>

</html>