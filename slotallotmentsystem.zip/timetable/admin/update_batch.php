<?php include "Header.php" ?> <!-- Page (2 columns) -->
<div id="page" class="box">
    <div id="page-in" class="box"> <!-- Content -->
        <div id="content"> <!-- Article -->
            <div class="article">
                <h2><span>Batch Details</span></h2>

                <div class="login">
                    <?php
                    $id = $_GET['id'];
                    $selectQuery = "SELECT * FROM batch WHERE b_id = $id";
                    $result = $dbConnection->query($selectQuery);
                    if ($result->num_rows > 0) {
                        // Fetch the data from the result set
                        $row = $result->fetch_assoc();
                        ?>
                        <form action="./php/update_batch.php?id=<?php echo $id ?>" method="post" id="form2">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td>Batch Year :</td>
                                    <td><input type="text" value="<?php echo $row['b_year'] ?>" name="b_year"
                                            id="txtName1" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>Batch start date :</td>
                                    <td>
                                       <input type="date" value="<?php echo $row['b_startDate'] ?>" name="b_startDate"
                                            id="txtName1" />
                                    </td>
                                </tr>
                                <tr>
                                   <td>Batch end date :</td>
                                    <td>
                                       <input type="date" value="<?php echo $row['b_endDate'] ?>" name="b_endDate"
                                            id="txtName1" />
                                    </td>
                                </tr>
                              
                                <tr>
                                    <td colspan="2"><label> <label></label>
                                            <div align="center"> <input type="submit" name="button2" id="button2"
                                                    value="Update" />
                                            </div>
                                        </label></td>
                                </tr>
                            </table>
                        </form>
                    <?php } ?>
                </div>
                </table>
                </form>
            </div>
        </div> <!-- /article -->
        <hr class="noscreen" />
        <?php include "right.php" ?>
    </div> <!-- /content -->
</div> <!-- /page-in -->
<?php include "footer.php" ?>
</div> <!-- /page -->