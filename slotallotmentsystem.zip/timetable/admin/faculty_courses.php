<?php include "Header.php" ?> <!-- Page (2 columns) -->
<div id="page" class="box">
  <div id="page-in" class="box"> <!-- Content -->
    <div id="content"> <!-- Article -->
      <div class="article">
        <h2><span>Faculty Courses</span></h2>
        <form action="./php/importFacultyCourse.php" method="post" enctype="multipart/form-data">
          <input type="file" class="button2" name="file" required value="">
          <button type="submit" class="button2" name="import">Import</button>
        </form>
        <p>
          <?php if (isset($_SESSION['message'])) {
            echo $_SESSION['message'];
            unset($_SESSION['message']);
          } ?>
        </p>
        <table width="100%" border="1" cellpadding="1" cellspacing="2" bordercolor="#006699">
          <tr>
            <th bgcolor="#006699" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Name</strong></div>
            </th>
          
            <th bgcolor="#006699" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Subject</strong></div>
            </th>
             <th bgcolor="#006699" class="style3">
              <div align="left" class="style9 style5 style2"><strong>session</strong></div>
            </th>
            <th bgcolor="#006699" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Update subjects</strong></div>
            </th>
            <th bgcolor="#006699" class="style3">
              <div align="left" class="style9 style5 style2"><strong>Delete</strong></div>
            </th>

          </tr>
          <?php $selectQuery = "SELECT
              tc.tc_id as tc_id,
              tc.session as session,
              t.t_name AS t_name,
              c.c_title AS c_name
          FROM
              teachers_courses tc
          INNER JOIN
              teachers t ON tc.teacher_id = t.t_id
          INNER JOIN
              courses c ON tc.course_id = c.c_id;
          ";
          $result = $dbConnection->query($selectQuery);
          if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) { ?>
            
              <tr>
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <?php echo $row['t_name']; ?>
                  </div>
                </td>
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <?php echo $row['c_name']; ?>
                  </div>
                </td>
                <td class="style3">
                  <div align="left" class="style9 style5 style2">
                    <?php echo $row['session']; ?>
                  </div>
                </td>
                <td class="style3">
                  <div align="left" class="style9 style5 style2" > <a
                      href="updateFacultyCourse.php?id=<?php echo $row['tc_id']; ?>">update
                      subjects</a>
                  </div>
                </td>
                <td class="style3">
                  <div align="left" class="style9 style5 style2"> <a
                      href="./php/deleteFacultyCourse.php?id=<?php echo $row['tc_id']; ?>">Delete</a>
                  </div>
                </td>
              </tr>
            <?php }
          } ?>
        </table>
        <div style="text-align:center;"> <a href="addfacultyCourse.php" class="button2" style="vertical-align:middle"><span>
              add course</span></a> </div>
        <p class="btn-more box noprint">&nbsp;</p>
      </div> <!-- /article -->
    </div> <!-- /content -->
    <?php include "right.php" ?>
  </div> <!-- /page-in -->
</div> <!-- /page -->
<?php include "footer.php" ?>