<?php include "Header.php" ?>
<div id="page" class="box">
	<div id="page-in" class="box">

		<div id="content">

			<div class="article">
				<h2><span>Student Details</span></h2>
				<div class="login">
					<form action="./php/addStudent.php" method="post" enctype="multipart/form-data" id="form2">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td>Student id:</td>
								<td> <input type="text" name="s_id" id="txtName" />
								</td>
							</tr>
                            <tr>
								<td>Student Name:</td>
								<td> <input type="text" name="s_name" id="txtName" />
								</td>
							</tr>
							
							<tr>
								<td>Session:</td>
								<td>
									<select style="width:100%" name="s_session">
									<option selected disabled>select session</option>
										<option value='1'>Morning</option>
										<option value='0'>Evening</option>
									</select>

								</td>
							</tr>
							<tr>
								<td>Batch:</td>
								<td>
									<select style="width:100%" name="s_batch">
									 <option value="" disabled selected>Select a batch</option>
										<?php
										$selectQuery = "SELECT * FROM batch ORDER BY b_id DESC";
										$result = $dbConnection->query($selectQuery);
										if ($result->num_rows > 0) {
											while ($row = $result->fetch_assoc()) {
												echo "<option value='" . $row["b_id"] . "'>" . $row["b_year"] . "</option>";
											}
										} ?>
									</select>

								</td>
							</tr>
							<tr>
								<td colspan="2"><label> <label></label>
										<div align="center"> <input type="submit" name="button2" id="button2"
												value="Submit" /> </div>
									</label></td>
							</tr>
						</table>
					</form>
				</div>
				<p class="btn-more box noprint">&nbsp;</p>
			</div> <!-- /article -->

		</div> <!-- /content -->
		<?php include "right.php" ?>
	</div> <!-- /page-in -->
	<?php include "footer.php" ?>
</div>