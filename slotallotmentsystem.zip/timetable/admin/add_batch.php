<?php include "Header.php" ?> <!-- Page (2 columns) -->
<div id="page" class="box">
   <div id="page-in" class="box"> <!-- Content -->
      <div id="content"> <!-- Article -->
         <div class="article">
            <h2><span>Batch Details</span></h2>
            <div class="login">
               <form action="./php/batch_insert.php" method="post" id="form2">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                     <tr>
                        <td>Batch Year :</td>
                        <td><input type="text" name="b_year" id="txtName1" />
                        </td>
                     </tr>
                    
                     <tr>
                        <td>Batch start date :</td>
                        <td><input type="date" name="b_start" id="txtName1" />
                        </td>
                     </tr>
                     <tr>
                        <td>Batch end date :</td>
                        <td><input type="date" name="b_end" id="txtName1" />
                        </td>
                     </tr>
                    
              </tr> 
                     <tr>
                        <td colspan="2"><label> <label></label>
                              <div align="center"> <input type="submit" name="button2" id="button2" value="Add" />
                              </div>
                           </label></td>
                     </tr>
                  </table>
               </form>
            </div>
            </table>
            </form>
         </div>
      </div> <!-- /article -->
      <hr class="noscreen" />
      <?php include "right.php" ?>
   </div> <!-- /content -->
</div> <!-- /page-in -->
<?php include "footer.php" ?>
</div> <!-- /page -->