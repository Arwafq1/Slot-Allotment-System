<?php include "Header.php" ?>
<div id="page" class="box">
	<div id="page-in" class="box">

		<div id="content">

			<div class="article">
				<h2><span>Faculty Details</span></h2>
				<div class="login">
					<form action="./php/addFaculty.php" method="post" enctype="multipart/form-data" id="form2">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td>Faculty Name:</td>
								<td> <input type="text" name="t_name" id="txtName" />
								</td>
							</tr>
							<tr>
								<td>Email:</td>
								<td><input type="email" name="t_email" id="txtEmail" /></td>
							</tr>
							<tr>
								<td colspan="2"><label> <label></label>
										<div align="center"> <input type="submit" name="button2" id="button2"
												value="Submit" /> </div>
									</label></td>
							</tr>
						</table>
					</form>
				</div>
				<p class="btn-more box noprint">&nbsp;</p>
			</div> <!-- /article -->

		</div> <!-- /content -->
		<?php include "right.php" ?>
	</div> <!-- /page-in -->
	<?php include "footer.php" ?>
</div>