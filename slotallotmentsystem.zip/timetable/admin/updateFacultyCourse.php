<?php include "Header.php" ?>
<div id="page" class="box">
    <div id="page-in" class="box">

        <div id="content">

            <div class="article">
                <h2><span>Faculty Details</span></h2>
                <div class="login">
                    <?php
                    $id = $_GET['id'];
                    $selectQuery = "SELECT * FROM teachers_courses WHERE tc_id = $id";
                    $result = $dbConnection->query($selectQuery);
                    if ($result->num_rows > 0) {
                        // Fetch the data from the result set
                        $row = $result->fetch_assoc();
                        ?>
                        <form action="./php/updateFacultyCourse.php?id=<?php echo $id ?>" method="post"
                            enctype="multipart/form-data" id="form2">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td>Faculty Name:</td>
                                    <td> <select style="width:100%" name="teacher">
										<?php
										$teacherQuery = "SELECT * FROM teachers ORDER BY t_name DESC";
										$teacherQueryResult = $dbConnection->query($teacherQuery);
										if ($teacherQueryResult->num_rows > 0) {
											while ($teachers = $teacherQueryResult->fetch_assoc()) {
                                                $selected = ($row["teacher_id"] == $teachers['t_id']) ? 'selected' : '';
												echo "<option " . $selected . "  value='" . $teachers["t_id"] . "'>" . $teachers["t_name"] . "</option>";
											}
										} ?>
									</select>
								</td>
                                </tr>
                                <tr>
                                    <td>subject:</td>
                                   <td> <select style="width:100%" name="course_id">
										<?php
										$courseQuery = "SELECT * FROM courses ORDER BY c_id DESC";
										$resultCourseQuery = $dbConnection->query($courseQuery);
										if ($resultCourseQuery->num_rows > 0) {
											while ($course = $resultCourseQuery->fetch_assoc()) {
                                                $selected = ($row["course_id"] == $course['c_id']) ? 'selected' : '';
												echo "<option " . $selected . " value='" . $course["c_id"] . "'>" . $course["c_title"] . "</option>";
											}
										} ?>
									</select>
								</td>
                                </tr>
                                <tr>
								<td>session:</td>
								 <td>
									<select style="width:100%" name="session">
										<option value="" disabled selected>Select a session</option>
										<option value="morning" <?php echo ($row['session']) == "morning" ? "selected":"" ?> >morning</option>
										<option value="evening" <?php echo ($row['session']) == "evening" ? "selected":"" ?> >evening</option>
									</select>
								</td>
							</tr>
                                <tr>
                                    <td colspan="2"><label> <label></label>
                                            <div align="center"> <input type="submit" name="button2" id="button2"
                                                    value="Update" /> </div>
                                        </label></td>
                                </tr>
                            </table>
                        </form>
                    <?php } ?>
                </div>
                <p class="btn-more box noprint">&nbsp;</p>
            </div> <!-- /article -->

        </div> <!-- /content -->
        <?php include "right.php" ?>
    </div> <!-- /page-in -->
    <?php include "footer.php" ?>