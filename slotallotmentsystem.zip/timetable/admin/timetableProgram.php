<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timetable with Drag and Drop</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            min-width: 150px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        .draggable {
            display:flex;
            align-items: center;
            justify-content: center;
            gap:10;
            cursor: pointer;
            background-color: #e0e0e0;
            padding: 5px;
            border-radius: 5px;
            margin-block: 5px;
        }

        .draggable:hover {
            background-color: #ccc;
        }

        .dragging {
            opacity: 0.6;
        }

        .droppable {
            border: 2px dashed #aaa;
            min-height: 100px;
        }
    </style>
</head>
<body>
    <table>
        <!-- Table header with time slots at the top -->
        <thead>
            <tr>
                <th></th>
                <th>9:00 AM - 10:30 AM</th>
                <th>11:00 AM - 12:30 PM</th>
                <th>12:35 PM - 2:05 PM</th>
                <th>2:10 PM - 3:40 PM</th>
                <th>4:00 PM - 5:30 PM</th>
            </tr>
        </thead>
        <!-- Table body with days and sessions -->
        <tbody id="timetableBody"></tbody>
    </table>

</form>

    <script>


        // Define days, sessions, and time slots
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
        const sessions = ['morning', 'evening'];
        const timeSlots = [
            '9:00 AM - 10:30 AM',
            '11:00 AM - 12:30 PM',
            '12:35 PM - 2:05 PM',
            '2:10 PM - 3:40 PM',
            '4:00 PM - 5:30 PM',
        ];
let data = [];
        // Function to populate the table with fetched data using map
       // Function to populate the table with fetched data using map
function populateTimetable(data) {
    const tableBody = document.getElementById('timetableBody');

    // Loop through the days and create table rows
    days.forEach((day) => {
        // Create a morning row
        const morningRow = document.createElement('tr');
        morningRow.innerHTML = `<td rowspan="2">${day}</td>`;

        // Create an evening row
        const eveningRow = document.createElement('tr');

        // Loop through the time slots and create table cells for both rows
        timeSlots.forEach((timeSlot) => {
            const morningCell = document.createElement('td');
            const eveningCell = document.createElement('td');

            // Retrieve entries for morning and evening sessions
            const morningEntries = data[day]?.morning?.[timeSlot];
            const eveningEntries = data[day]?.evening?.[timeSlot];

            if (morningEntries && morningEntries.length > 0) {
                morningEntries.forEach((entry) => {
                    // Create a div for each entry
                    const entryDiv = createEntryDiv(entry,timeSlot);
                    morningCell.appendChild(entryDiv);
                });
            }

            if (eveningEntries && eveningEntries.length > 0) {
                eveningEntries.forEach((entry) => {
                    // Create a div for each entry
                    const entryDiv = createEntryDiv(entry);
                    eveningCell.appendChild(entryDiv);
                });
            }

            // Append cells to rows
            morningRow.appendChild(morningCell);
            eveningRow.appendChild(eveningCell);
        });

        // Append morning and evening rows to the table body
        tableBody.appendChild(morningRow);
        tableBody.appendChild(eveningRow);
    });

}





// Helper function to create an entry div
function createEntryDiv(entry) {
    const entryDiv = document.createElement('div');
    entryDiv.className = 'draggable';
    entryDiv.innerHTML = `
    <p data-subject> ${entry.subject}</p>
    <p data-room> (${entry.room})</p>
    `;
    entryDiv.draggable = true; // Make the entry draggable
    return entryDiv;
}


        // Populate the table with the sample timetable data
        function fetchTimetable() {
            // Create a new XMLHttpRequest object
            var xhr = new XMLHttpRequest();

            // Define the URL of the PHP file that retrieves the data
            var url = 'get_approvetimetable.php';

            // Configure the request
            xhr.open('GET', url, true);

            // Set up an event handler to process the response
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);

                    // Check for errors
                    if (response.hasOwnProperty('error')) {
                        alert('Error: ' + response.error);
                    } else {
                        // Call a function to populate the table with the fetched data
                        data =response;
                        populateTimetable(response);
                    }
                }
            };

            // Send the request
            xhr.send();
        }
            fetchTimetable();


    </script>
</body>
</html>
