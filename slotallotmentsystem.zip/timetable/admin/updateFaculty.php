<?php include "Header.php" ?>
<div id="page" class="box">
    <div id="page-in" class="box">

        <div id="content">

            <div class="article">
                <h2><span>Faculty Details</span></h2>
                <div class="login">
                    <?php
                    $id = $_GET['id'];
                    $selectQuery = "SELECT * FROM teachers WHERE t_id = $id";
                    $result = $dbConnection->query($selectQuery);
                    if ($result->num_rows > 0) {
                        // Fetch the data from the result set
                        $row = $result->fetch_assoc();
                        ?>
                        <form action="./php/updateFaculty.php?id=<?php echo $id ?>" method="post"
                            enctype="multipart/form-data" id="form2">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td>Faculty Name:</td>
                                    <td> <input type="text" value="<?php echo $row['t_name'] ?>" name="t_name" id="txtName" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>Email:</td>
                                    <td><input type="email" value="<?php echo $row['t_email'] ?>" name="t_email"
                                            id="txtEmail" /></td>
                                </tr>
                                <tr>
                                    <td colspan="2"><label> <label></label>
                                            <div align="center"> <input type="submit" name="button2" id="button2"
                                                    value="Update" /> </div>
                                        </label></td>
                                </tr>
                            </table>
                        </form>
                    <?php } ?>
                </div>
                <p class="btn-more box noprint">&nbsp;</p>
            </div> <!-- /article -->

        </div> <!-- /content -->
        <?php include "right.php" ?>
    </div> <!-- /page-in -->
    <?php include "footer.php" ?>