<?php include "Header.php" ?> <!-- Page (2 columns) -->
<div id="page" class="box">
   <div id="page-in" class="box"> <!-- Content -->
      <div id="content"> <!-- Article -->
         <div class="article">
            <h2><span>Semester Details</span></h2>
            <div class="login">
                 <?php
                    $s_id = $_GET['id'];
                    $selectQuery = "SELECT * FROM semester WHERE sem_id = '$s_id'";
                    $result = $dbConnection->query($selectQuery);
                    if ($result->num_rows > 0) {
                        // Fetch the data from the result set
                        $row = $result->fetch_assoc();
                        ?>
               <form action="./php/updateSemester.php?id=<?php echo $s_id ?>" method="post" id="form2">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                     <tr>
                        <td>Session:</td>
                        <td>
                            <select style="width:100%" name="session">
                                <option value="" disabled selected>Select a session</option>
                                <option value="morning" <?php echo ($row["session"] == "morning") ? 'selected' : ''; ?> >Morning</option>
                                <option value="evening" <?php echo ($row["session"] == "evening") ? 'selected' : ''; ?> >Evening</option>
                            </select>
                        </td>
                     </tr>
                     <tr>
                        <td>Program:</td>
                        <td>
                            <select style="width:100%" name="program">
                                <option value="" disabled selected>Select a program</option>
                                <option value="fall" <?php echo ($row["s_program"] == "fall") ? 'selected' : ''; ?> >fall</option>
                                <option value="spring" <?php echo ($row["s_program"] == "spring") ? 'selected' : ''; ?>>spring</option>
                                <option value="summer" <?php echo ($row["s_program"] == "summer") ? 'selected' : ''; ?>>summer</option>
                            </select>
                        </td>
                     </tr>
                     <tr>
                        <td>semester start date :</td>
                        <td><input type="date" name="s_start" value="<?php echo $row['s_start'] ?>" id="txtName1" />
                        </td>
                     </tr>
                     <tr>
                        <td>semester end date :</td>
                        <td><input type="date" name="s_end" value="<?php echo $row['s_end'] ?>" id="txtName1" />
                        </td>
                     </tr>
                    
              </tr> 
                     <tr>
                        <td colspan="2"><label> <label></label>
                              <div align="center"> <input type="submit" name="button2" id="button2" value="Add" />
                              </div>
                           </label></td>
                     </tr>
                  </table>
               </form>
               <?php } ?>
            </div>
            </table>
            </form>
         </div>
      </div> <!-- /article -->
      <hr class="noscreen" />
      <?php include "right.php" ?>
   </div> <!-- /content -->
</div> <!-- /page-in -->
<?php include "footer.php" ?>
</div> <!-- /page -->