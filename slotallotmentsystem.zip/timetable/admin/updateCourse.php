<?php include "Header.php" ?> <!-- Page (2 columns) -->
<div id="page" class="box">
    <div id="page-in" class="box"> <!-- Content -->
        <div id="content"> <!-- Article -->
            <div class="article">
                <h2><span>Add New Course</span></h2>
                <div class="login">
                    <?php
                    $id = $_GET['id'];
                    $selectQuery = "SELECT * FROM courses WHERE c_id = '$id'";
                    $result = $dbConnection->query($selectQuery);
                    if ($result->num_rows > 0) {
                        // Fetch the data from the result set
                        $row = $result->fetch_assoc();
                        ?>
                        <form action="./php/updateCourse.php?id=<?php echo $id ?>" method="post" id="form2">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                 <tr>
                                    <td>Course id:</td>
                                    <td><input type="text" value="<?php echo $row["c_id"] ?>" name="c_id"
                                            id="txtName1" /></td>
                                </tr>
                                <tr>
                                    <td>Course Name:</td>
                                    <td><input type="text" value="<?php echo $row["c_title"] ?>" name="c_title"
                                            id="txtName1" /></td>
                                </tr>

                                <tr>
                                    <td>credit hours</td>
                                    <td><input type="text" value="<?php echo $row["c_credit"] ?>" name="c_credit"
                                            id="txtName2" /></td>
                                </tr>
                                <tr>
                                    <td>semester</td>
                                    <td><input type="text" value="<?php echo $row["c_semester"] ?>" name="c_semester"
                                            id="txtName2" /></td>
                                </tr>
                              
                                 <tr>
                                    <td>Lab:</td>
                                     <td>
                                        <select name="c_lab">
                                        <option disabled >select lab</option>
                                        <option value="1" <?php if ($row['c_lab'] == 1) echo 'selected'; ?>>Yes</option>
                                        <option value="0" <?php if ($row['c_lab'] == 0) echo 'selected'; ?>>No</option>
                                    </select>
                                            </div>
                                        </td>
                                </tr>
                                <tr>
                                    <td colspan="2"><label> <label></label>
                                            <div align="center"> <input type="submit" name="button2" class="button2"
                                                    value="Update" /> </div>
                                        </label></td>
                                </tr>
                            </table>
                        </form>
                    <?php } ?>
                </div>
                </table>
                </form>
            </div>
            <p class="btn-more box noprint">&nbsp;</p>
        </div> <!-- /article -->
        <hr class="noscreen" />
        <?php include "right.php" ?>
    </div> <!-- /content -->
</div> <!-- /page-in -->
<?php include "footer.php" ?>
</div> <!-- /page -->