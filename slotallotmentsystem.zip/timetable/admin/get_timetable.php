<?php
include "../conn.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $timetable = [];

    $sql = "SELECT * FROM timetable WHERE id = '$id'";
    $result = $dbConnection->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $time = $row['timetable'];
                $table = unserialize($time);
                $timetable = $table;
            }
        }
    }

    // Return the timetable data as JSON
    header('Content-Type: application/json');
    echo json_encode($timetable);
} else {
    // Handle the case where 'id' is not set
    echo json_encode(['error' => 'Missing parameter: id']);
}
