<?php include "Header.php"?>
<div id="page" class="box">
	<div id="page-in" class="box">
		<div id="content">
			<div class="article">
				<h2><span>Student Course Details</span></h2>
				<div class="login">
					<form action="./php/addStudentCourse.php" method="post" enctype="multipart/form-data" id="form2">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td>Student Name:</td>
								<td>
									<select style="width:100%" name="student_name">
										<option value="" disabled selected>Select student</option>
										<?php
$studentQuery = "SELECT * FROM students ORDER BY s_id DESC";
$resultStudentQuery = $dbConnection->query($studentQuery);
if ($resultStudentQuery->num_rows > 0) {
    while ($student = $resultStudentQuery->fetch_assoc()) {
        echo "<option value='" . $student["s_id"] . "'>" . $student["s_name"] . "</option>";
    }
}?>
									</select>
								</td>
							</tr>
							<tr>
								<td>Student Course:</td>
								<td>
                                    <select style="width:100%" name="c_id">
									 <option value="" disabled selected>Select a batch</option>
										<?php $courseQuery = "SELECT * FROM courses ORDER BY c_id DESC";
$resultCourseQuery = $dbConnection->query($courseQuery);
if ($resultCourseQuery->num_rows > 0) {
    while ($course = $resultCourseQuery->fetch_assoc()) {
        echo "<option value='" . $course["c_id"] . "'>" . $course["c_title"] . "</option>";
    }
}?>
									</select>
								</td>
							</tr>

							<tr>
								<td colspan="2"><label> <label></label>
										<div align="center"> <input type="submit" name="button2" id="button2"
												value="Submit" /> </div>
									</label></td>
							</tr>
						</table>
					</form>
				</div>
				<p class="btn-more box noprint">&nbsp;</p>
			</div> <!-- /article -->

		</div> <!-- /content -->
		<?php include "right.php"?>
	</div> <!-- /page-in -->
	<?php include "footer.php"?>
</div>