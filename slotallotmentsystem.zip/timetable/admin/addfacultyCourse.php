<?php include "Header.php" ?>
<div id="page" class="box">
	<div id="page-in" class="box">

		<div id="content">

			<div class="article">
				<h2><span>Faculty Details</span></h2>
				<div class="login">
					<form action="./php/addfacultyCourse.php" method="post" enctype="multipart/form-data" id="form2">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td>Faculty Name:</td>
								<td> <select style="width:100%" name="teacher_id">
										<option value="" disabled selected>Select a teacher</option>
										<?php
										$selectQuery = "SELECT * FROM teachers ORDER BY t_name DESC";
										$result = $dbConnection->query($selectQuery);
										if ($result->num_rows > 0) {
											while ($row = $result->fetch_assoc()) {
												echo "<option value='" . $row["t_id"] . "'>" . $row["t_name"] . "</option>";
											}
										} ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>subject:</td>
								<td>
									<select style="width:100%" name="course_id">
										<option value="" disabled selected>Select a course</option>
										<?php
										$selectQuery = "SELECT * FROM courses ORDER BY c_id DESC";
										$result = $dbConnection->query($selectQuery);
										if ($result->num_rows > 0) {
											while ($row = $result->fetch_assoc()) {
												echo "<option value='" . $row["c_id"] . "'>" . $row["c_title"] . "</option>";
											}
										} ?>
									</select>

								</td>
							</tr>
							<tr>
								<td>session:</td>
								 <td>
									<select style="width:100%" name="session">
										<option value="" disabled selected>Select a session</option>
										<option value="morning" >morning</option>
										<option value="evening" >evening</option>
									</select>
								</td>
							</tr>
							<tr>
								<td colspan="2"><label> <label></label>
										<div align="center"> <input type="submit" name="button2" id="button2"
												value="Submit" /> </div>
									</label></td>
							</tr>
						</table>
					</form>
				</div>
				<p class="btn-more box noprint">&nbsp;</p>
			</div> <!-- /article -->

		</div> <!-- /content -->
		<?php include "right.php" ?>
	</div> <!-- /page-in -->
	<?php include "footer.php" ?>
</div>