<div id="tabs">
  <ul class="box">
    <li><a href="index.php">Home<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="course_details.php">Course Details<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="room_detail.php">Room Details<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="faculty_details.php">Faculty Details<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="faculty_courses.php">Faculty Courses<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="student_details.php">Student Details<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="student_course.php">Student Courses<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="semesterView.php">Semester Management<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="batch_detail.php">Batch Management<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="generate.php">Generate Time Table<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a target="_blank" href="timetableProgram.php">Time Table<span class="tab-l"></span><span class="tab-r"></span></a></li>
    <li><a href="Logout.php">Logout<span class="tab-l"></span><span class="tab-r"></span></a></li>
  </ul>
  <hr class="noscreen" />
</div>