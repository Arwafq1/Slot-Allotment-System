<?php include "Header.php" ?>
<!-- Page (2 columns) -->
<div id="page" class="box">
    <div id="page-in" class="box">
        <!-- Content -->
        <div id="content">
            <div class="article">
                <h2><span>QUAID-E-AZAM UNIVERSITY</span></h2>
                <p> <span class="style2">I</span>nstitute Of Information Technology</p>
                <p align="right"> <img src="./images.jpg" alt="" width="450" height="200" /></p>
                <p class="btn-more box noprint">&nbsp;</p>
            </div>
        </div>
        <?php
        include "right.php"
            ?>
    </div>
</div>
<?php
include "footer.php"
    ?>