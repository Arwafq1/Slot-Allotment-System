<?php
session_start();
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Database creation query
$databaseName = "ntimetable";
$createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS $databaseName";

// Create the database if it doesn't exist
if ($conn->query($createDatabaseQuery) === true) {
    // echo "Database created successfully or already exists\n";

    $dbConnection = new mysqli($servername, $username, $password, $databaseName);
    if ($dbConnection->connect_error) {
        die("Connection to database failed: " . $dbConnection->connect_error);
    }
    // echo "Table 'user' created successfully or already exists\n";

    // Check if any records exist in the "user" table
    $checkQuery = "SELECT COUNT(*) as count FROM user";
    $result = $dbConnection->query($checkQuery);
    $row = $result->fetch_assoc();
    $recordCount = $row['count'];

    // Insert data only if no records exist in the "user" table
    if ($recordCount == 0) {

        $insertQuery = "INSERT INTO user (firstname,lastname,email, password, role) VALUES
    ('firstname','lastname','admin@gmail.com', '" . password_hash('admin', PASSWORD_DEFAULT) . "', 'admin'),
    ('firstname','lastname','hod@gmail.com', '" . password_hash('admin', PASSWORD_DEFAULT) . "', 'hod')";

        if ($dbConnection->query($insertQuery) === true) {
            // echo "Values inserted successfully\n";
        } else {
            echo "Error inserting values: " . $dbConnection->error;
        }
    } else {
        // echo "Data already exists in the 'user' table\n";
    }

} else {
    echo "Error creating database: " . $conn->error;
}
