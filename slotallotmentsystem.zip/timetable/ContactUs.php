<?php
include "Header.php"
  ?>

<!-- Page (2 columns) -->
<div id="page" class="box">
  <div id="page-in" class="box">
    <div id="content">
      <!-- Article -->
      <div class="article">
        <h2><span>Contact Us</span></h2>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="6%"><img src="design/ico_archive2.gif" alt="" width="9" height="11" /></td>
            <td width="94%"><strong>Quaid-i-Azam univeristy<br />
              </strong></td>
          </tr>
          <tr>
            <td><img src="design/ico_archive2.gif" alt="" width="9" height="11" /></td>
            <td><strong>Phone: +923012345678</strong></td>
          </tr>

        </table>

        <p>&nbsp;</p>

        <p class="btn-more box noprint">&nbsp;</p>
      </div> <!-- /article -->

      <hr class="noscreen" />

    </div> <!-- /content -->

    <?php
    include "right.php"
      ?>

  </div> <!-- /page-in -->
</div> <!-- /page -->


<?php
include "footer.php"
  ?>