<?php
include "Header.php"
    ?>
<!-- Page (2 columns) -->
<div id="page" class="box">
    <div id="page-in" class="box">


        <!-- Content -->
        <div id="content">


            <div class="article">
                <h2><span>About Us</span></h2>


                <p>Welcome to IIT department's time table website! We are dedicated to providing a seamless and
                    efficient scheduling experience for our students, faculty, and staff.</p>


                <p class="btn-more box noprint">&nbsp;</p>
            </div> <!-- /article -->

            <hr class="noscreen" />

        </div> <!-- /content -->

        <?php
        include "right.php"
            ?>

    </div> <!-- /page-in -->
</div> <!-- /page -->


<?php
include "footer.php"
    ?>